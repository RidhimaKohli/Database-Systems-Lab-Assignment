/*

insert into Author_Details table with fields:Author_IDAuthor_Name
Da_001 Damasio
Mi_009 Minsky
Ra_001 Ramachandran
Ro_015 Rowling
Ru_021 Russel
Sa_001 Safina
Ta_001 Tagore
To_015 Tolkien
Wo_015 Wodehouse



*/
insert into Author_Details(Author_ID,Author_Name) values('Da_001','Damasio');
insert into Author_Details(Author_ID,Author_Name) values('Mi_009','Minsky');
insert into Author_Details(Author_ID,Author_Name) values('Ra_001','Ramachandran');
insert into Author_Details(Author_ID,Author_Name) values('Ro_015','Rowling');
insert into Author_Details(Author_ID,Author_Name) values('Ru_021','Russel');
insert into Author_Details(Author_ID,Author_Name) values('Sa_001','Safina');
insert into Author_Details(Author_ID,Author_Name) values('Ta_001','Tagore');
insert into Author_Details(Author_ID,Author_Name) values('To_015','Tolkien');
insert into Author_Details(Author_ID,Author_Name) values('Wo_015','Wodehouse');
/*

insert into Book_Details table with fields:Author_ID Book_ID Book 

Da_001 Da001_Sel Self Comes to Mind
Mi_009 Mi009_Emo Emotion Machine
Mi_009 Mi009_Soc Society of Mind
Ra_001 Ra001_Pha Phantoms in the Brain
Ro_015 Ro015_Fan Fantastic Beasts and Where to Find Them
Ro_015 Ro015_Gob Goblet of Fire_Harry Potter
Ro_015 Ro015_Phi Philosopher’s Stone_Harry Potter
Ro_015 Ro015_Pri Prisoner of Azkaban_Harry Potter
Sa_001 Sa001_Voy Voyage of the Turtle
Sa_001 Sa001_Wha
What Animals Think
To_015
To015_Fel
Fellowship of the Rings_Lord of the Rings
Wo_015
Wo015_Wod
Wodehouse at the Wicket



*/
insert into Book_Details(Author_ID,Book_ID,Book) values('Da_001','Da001_Sel','Self Comes to Mind');
insert into Book_Details(Author_ID,Book_ID,Book) values('Mi_009','Mi009_Emo','Emotion Machine');
insert into Book_Details(Author_ID,Book_ID,Book) values('Mi_009','Mi009_Soc','Society of Mind');
insert into Book_Details(Author_ID,Book_ID,Book) values('Ra_001','Ra001_Pha','Phantoms in the Brain');
insert into Book_Details(Author_ID,Book_ID,Book) values('Ro_015','Ro015_Fan','Fantastic Beasts and Where to Find Them');
insert into Book_Details(Author_ID,Book_ID,Book) values('Ro_015','Ro015_Gob','Goblet of Fire_Harry Potter');
insert into Book_Details(Author_ID,Book_ID,Book) values('Ro_015','Ro015_Phi','Philosopher’s Stone_Harry Potter');
insert into Book_Details(Author_ID,Book_ID,Book) values('Ro_015','Ro015_Pri','Prisoner of Azkaban_Harry Potter');
insert into Book_Details(Author_ID,Book_ID,Book) values('Sa_001','Sa001_Voy','Voyage of the Turtle');
insert into Book_Details(Author_ID,Book_ID,Book) values('Sa_001','Sa001_Wha','What Animals Think');
insert into Book_Details(Author_ID,Book_ID,Book) values('To_015','To015_Fel','Fellowship of the Rings_Lord of the Rings');
insert into Book_Details(Author_ID,Book_ID,Book) values('Wo_015','Wo015_Wod','Wodehouse at the Wicket');

/*
Insert into Book_Purchase_Details with fields Book_ID Purchase_Dt Copies Price Purchase_Price Book_Value
Da001_Sel
Sep 1, 2021
1
50

Da001_Sel
Sep 7, 2021
5
50
Mi009_Emo
Sep 2, 2021
2
50
Mi009_Soc
Sep 1, 2021
2
50
Ra001_Pha
Sep 2, 2021
2
50
Ro015_Fan
Sep 1, 2021
3
50
Ro015_Fan
Sep 9, 2021
12
35
Ro015_Gob
Sep 1, 2021
3
50
Ro015_Phi
Sep 1, 2021
3
50
Ro015_Phi
Sep 10, 2021
20
75
Ro015_Pri
Sep 1, 2021
3
50
Sa001_Voy
Sep 2, 2021
2
50
Sa001_Wha
Sep 2, 2021
2
50
To015_Fel
Sep 1, 2021
3
50
To015_Fel
Sep 12, 2021
9
55
Wo015_Wod
Sep 5, 2021
1
50




*/

Insert into Book_Purchase_Details(Book_ID,Purchase_Dt,Copies,Price,Purchase_Price,Book_Value) values('Da001_Sel','Sep 1, 2021',1,50,0,0);
Insert into Book_Purchase_Details(Book_ID,Purchase_Dt,Copies,Price,Purchase_Price,Book_Value) values('Da001_Sel','Sep 7, 2021',5,50,0,0);
Insert into Book_Purchase_Details(Book_ID,Purchase_Dt,Copies,Price,Purchase_Price,Book_Value) values('Mi009_Emo','Sep 2, 2021',2,50,0,0);
Insert into Book_Purchase_Details(Book_ID,Purchase_Dt,Copies,Price,Purchase_Price,Book_Value) values('Mi009_Soc','Sep 1, 2021',2,50,0,0);
Insert into Book_Purchase_Details(Book_ID,Purchase_Dt,Copies,Price,Purchase_Price,Book_Value) values('Ra001_Pha','Sep 2, 2021',2,50,0,0);
Insert into Book_Purchase_Details(Book_ID,Purchase_Dt,Copies,Price,Purchase_Price,Book_Value) values('Ro015_Fan','Sep 1, 2021',3,50,0,0);
Insert into Book_Purchase_Details(Book_ID,Purchase_Dt,Copies,Price,Purchase_Price,Book_Value) values('Ro015_Fan','Sep 9, 2021',12,35,0,0);
Insert into Book_Purchase_Details(Book_ID,Purchase_Dt,Copies,Price,Purchase_Price,Book_Value) values('Ro015_Gob','Sep 1, 2021',3,50,0,0);
Insert into Book_Purchase_Details(Book_ID,Purchase_Dt,Copies,Price,Purchase_Price,Book_Value) values('Ro015_Phi','Sep 1, 2021',3,50,0,0);
Insert into Book_Purchase_Details(Book_ID,Purchase_Dt,Copies,Price,Purchase_Price,Book_Value) values('Ro015_Phi','Sep 10, 2021',20,75,0,0);
Insert into Book_Purchase_Details(Book_ID,Purchase_Dt,Copies,Price,Purchase_Price,Book_Value) values('Ro015_Pri','Sep 1, 2021',3,50,0,0);
Insert into Book_Purchase_Details(Book_ID,Purchase_Dt,Copies,Price,Purchase_Price,Book_Value) values('Sa001_Voy','Sep 2, 2021',2,50,0,0);
Insert into Book_Purchase_Details(Book_ID,Purchase_Dt,Copies,Price,Purchase_Price,Book_Value) values('Sa001_Wha','Sep 2, 2021',2,50,0,0);
Insert into Book_Purchase_Details(Book_ID,Purchase_Dt,Copies,Price,Purchase_Price,Book_Value) values('To015_Fel','Sep 1, 2021',3,50,0,0);
Insert into Book_Purchase_Details(Book_ID,Purchase_Dt,Copies,Price,Purchase_Price,Book_Value) values('To015_Fel','Sep 12, 2021',9,55,0,0);
Insert into Book_Purchase_Details(Book_ID,Purchase_Dt,Copies,Price,Purchase_Price,Book_Value) values('Wo015_Wod','Sep 5, 2021',1,50,0,0);
