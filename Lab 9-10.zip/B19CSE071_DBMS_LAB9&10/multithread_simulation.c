
#include <stdio.h>
#include <pthread.h>
#include <time.h>
#include <stdlib.h>

int shared_var = 0; // can be seen as a common database where transactions are executed
void* session(int id)
{
    printf("Session %d started\n", id);
    shared_var = id; // changes
    printf("Shared var value is %d now\n", shared_var);
 sleep(2);
    printf("Session %d ended\n", id);

}

int main()
{
    pthread_t t1, t2;
    pthread_create(&t1, NULL, session, (void*)1); // transaction 1
    pthread_create(&t2, NULL, session, (void*)2); // transaction 2
    pthread_join(t1, NULL);
    pthread_join(t2, NULL);
return 0;
} 