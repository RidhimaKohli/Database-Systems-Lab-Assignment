
#include <stdio.h>
#include <pthread.h>
#include <time.h>
#include <stdlib.h>


pthread_mutex_t mutex_item1;
pthread_mutex_t mutex_item2;


void* handlerSession(int id){
   //check if both mutex are locked
   sleep(5);
   while(1>0){
    if(pthread_mutex_trylock(&mutex_item1) == 0 && pthread_mutex_trylock(&mutex_item2) == 0){
      
        printf("Handler says everything is okay in this round\n");
    }
    else{
         printf("Session %d: both mutex are locked... Users report a DEADLOCK\n", id);
         printf("Development  team decides to receive consultancy service from an experienced database administrator\n");

         printf("-------------------------\n");
         printf("Database administrator looks at locks and decides to unlock one of them by a rollback\n");
        printf("<<<<<<      ROLLBACK A TRANSACTION    >>>>>>\n");

        pthread_mutex_unlock(&mutex_item1);
       
        break;
    }
   }

}



void* querySet1(int id)
{
    printf("querySet for transaction %d started\n", id);
    pthread_mutex_lock(&mutex_item1); 
    printf("querySet for transaction %d locked item1\n", id);
    printf("Transaction 1 is executing other statements.......And wants to acquire item 2 now\n");
    sleep(5);
    pthread_mutex_lock(&mutex_item2);
   
 sleep(2);
    printf("querySet for transaction %d ended\n", id);

}


void* querySet2(int id)
{
   
    printf("querySet for transaction %d started\n", id);
    pthread_mutex_lock(&mutex_item2);
    printf("querySet for transaction %d locked item2\n", id);
    printf("Transaction 2 is executing other statements......And wants to acquire item 1 now\n");
    pthread_mutex_lock(&mutex_item1);
 sleep(2);
    printf("querySet for transaction %d ended\n", id);
    
     pthread_mutex_unlock(&mutex_item1);
      pthread_mutex_unlock(&mutex_item2);
      printf("Transaction 2 has released the locks \n");
      printf("----------------\n");
    pthread_t t1;
    pthread_mutex_init(&mutex_item1, NULL);
    pthread_create(&t1, NULL, querySet1, (void*)1);


}

int main()
{
    pthread_t t1, t2 ,handlerThread;
    //initialise mutex
    pthread_mutex_init(handlerThread, NULL);
    pthread_mutex_init(&mutex_item1, NULL);
    pthread_mutex_init(&mutex_item2, NULL);
    pthread_create(&handlerThread, NULL, handlerSession, (void*)3); // transaction 3
    pthread_create(&t1, NULL, querySet1, (void*)1); // transaction 1
    pthread_create(&t2, NULL, querySet2, (void*)2); // transaction 2
   
    pthread_join(t1, NULL);
    pthread_join(t2, NULL);
    pthread_join(handlerThread, NULL);
    pthread_mutex_destroy(&mutex_item1);
    pthread_mutex_destroy(&mutex_item2);
return 0;
} 